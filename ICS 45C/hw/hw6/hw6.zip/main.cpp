#include "Shape.h"
#include "Rectangle.h"
#include "Circle.h"
#include "Triangle.h"
#include "Square.h"
#include "Picture.h"

using namespace std;

int main() {
	Triangle firstTriangle(0, 0, "triangle", 5, 5);
	Triangle secondTriangle(0, 0, "triangle", 4, 3);

	Triangle* t1 = &firstTriangle;
	Triangle* t2 = &secondTriangle;

	Circle firstCircle(0, 0, "circle", 5);
	Circle secondCircle(0, 0, "circle", 10);

	Circle* c1 = &firstCircle;
	Circle* c2 = &secondCircle;

	Square firstSquare(0, 0, "square", 5);
	Square secondSquare(0, 0, "square", 10);

	Square* s1 = &firstSquare;
	Square* s2 = &secondSquare;
	
	Rectangle firstRectangle(0, 0, "rectangle", 4, 8);
	Rectangle secondRectangle(0, 0, "rectangle", 8, 4);

	Rectangle* r1 = &firstRectangle;
	Rectangle* r2 = &secondRectangle;
	
	Picture p1;
	p1.add(t1);
	p1.add(t2);
	p1.add(c1);
	p1.add(c2);
	p1.add(s1);
	p1.add(s2);
	p1.add(r1);
	p1.add(r2);	

	cout << "area: " << p1.totalArea() << endl;
	p1.drawAll();

	return 0;
}
