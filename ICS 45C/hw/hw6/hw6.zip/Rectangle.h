#ifndef RECTANGLE_H
#define RECTANGLE_H

#include <iostream>

class Rectangle : public Shape {
public:
	Rectangle(int centerX, int centerY, std::string name, int s1, int s2) : Shape(centerX, centerY, name), side1(s1), side2(s2){
	}
	
	double area() const {
		return side1 * side2;
	}

	void draw() const {
		for (int i = 0; i < side1; i++) {
			std::cout << "*";
		}
		std::cout << std::endl;

		for (int i = 1; i < side2 - 1; i++) {
			std::cout << "*";
			for (int j = 1; j < side1 - 1; j++) {
				std::cout << " ";
			}
			std::cout << "*" << std::endl;
		}

		for (int i = 0; i < side1; i++) {
            std::cout << "*";
        }
        std::cout << std::endl;	
	}

protected:
	int side1;
	int side2;
};

#endif /* RECTANGLE_H */
