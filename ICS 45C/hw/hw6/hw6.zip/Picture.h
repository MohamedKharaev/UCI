#ifndef PICTURE_H
#define PICTURE_H

class Picture {
public:
	Picture() {

	}
	void add(Shape* sp) {
		head = new ListNode(sp, head);	
	}
	double totalArea() {
		double sum = 0;
		for (ListNode* l = head; l != nullptr; l = l -> next) {
			sum += l->info->area();
		}
		return sum;
	}
	void drawAll(){
		for (ListNode* L = head; L != nullptr; L = L -> next) {
			L -> info -> draw();
		}
	}

	~Picture() {
		deleteList(head);
	}
private:
	struct ListNode {
		Shape* info;
		ListNode* next;
		ListNode(Shape* newInfo, ListNode* newNext) : info(newInfo), next(newNext) {
		}
	};
	static void deleteList(ListNode* L) {
		if (L != nullptr) {
			deleteList(L->next);
			delete L;
		}
	}
	ListNode* head = nullptr;
};

#endif /* PICTURE_H */
