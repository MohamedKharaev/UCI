#ifndef SHAPE_H
#define SHAPE_H

#include <string>

class Shape {
public:
	Shape(int centerX, int centerY, std::string name) {
		x = centerX;
		y = centerY;
		shape_name = name;
	}
	virtual ~Shape() {}
	virtual double area() const = 0;
	virtual void draw() const = 0;

protected:
	int x;
	int y;
	std::string shape_name;
};

#endif /* SHAPE_H */

