#ifndef TRIANGLE_H
#define TRIANGLE_H

#include <string>
#include <iostream>

class Triangle : public Shape {
public:
	
	Triangle(int centerX, int centerY, std::string name, int b, int h) : Shape(centerX, centerY, name), base(b), height(h) {
	}

	double area() const {
		return .5 * base * height;
	}

	void draw() const {
		for (int i = 1; i <= height; i++) {
			for (int j = 1; j <= base / i + 1; j++) {
				std::cout << "*";
			}
			std::cout << std::endl;
		}
	}

protected:
	int base;
	int height;
};

#endif /* TRANIGLE_H */
