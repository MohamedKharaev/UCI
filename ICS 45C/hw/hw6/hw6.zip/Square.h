#ifndef SQUARE_H
#define SQUARE_H

#include "Rectangle.h"

#include <iostream>

class Square : public Rectangle {
public:
	Square(int centerX, int centerY, std::string name, int s) : Rectangle(centerX, centerY, name, s, s) {
	}
};

#endif /* SQUARE_H */
