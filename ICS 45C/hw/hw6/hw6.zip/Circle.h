#ifndef CIRCLE_H
#define CIRCLE_H

#include <iostream>

double pi = 3.1415926535897;

class Circle : public Shape {
public:
	Circle(int centerX, int centerY, std::string name, int r) : Shape(centerX, centerY, name), radius(r) {
	}
	
	double area() const {
		return pi * radius * radius;
	}

	void draw() const {
		for (int y = -1 * radius; y <= radius; y++) {
			for (int x = -1 * radius; x <= radius; x++) {
				if (y * y + x * x <= radius * radius) {
					std::cout << "*";
				}
				else {
					std::cout << " ";
				}
			}
			std::cout << std::endl;
		}
	}

protected:
	int radius;	

};

#endif /* CIRCLE_H */
