#define MAXLEN 128
class String
{
public:
	//Both constructors should construct this String from the parameter s
	explicit String( const char * s = "" )
	{
		strcpy(buf, s);
	}

	String( const String & s )
	{
		strcpy(buf, s.buf);
	}

	String operator = ( const String & s )
	{
		strcpy(buf, s.buf);
	}

	char & operator [] ( int index )
	{
		if(!inBounds(index))
		{
			cout << "String index out of bounds" << endl;
			index = 0;
		}
		return buf[index];
	}

	int size()
	{
		return strlen(buf);
	}

	String reverse()
	{
		char *temp_buf;
		reverse_cpy(temp_buf, buf);
		return String(temp_buf);
	}
	 // does not modify this String
	int indexOf( const char c )
	{
		int buflen = strlen(buf);
		for (int i = 0; i < buflen; ++i)
		{
			if (buf[i] == c)
			{
				return i;
			}
		}
		return -1;
	}

	int indexOf( const String pattern )
	{
		char * result = strstr(buf, pattern.buf);		
		int position = result - buf;
		int substringLength = strlen(buf) - position;
		return substringLength;
	}
		

	bool operator == ( const String s )
	{
		if (strcmp(buf, s.buf) == 0)
		{
			return true;
		}
		return false;
	}

    bool operator != ( const String s )
	{
		if ( strcmp( buf, s.buf ) != 0)
		{
			return true;
		}
		return false;
	}

	bool operator > ( const String s )
	{
		if (strcmp( buf, s.buf ) > 0)
		{
			return true;
		}
		return false;
	}

	bool operator < ( const String s )
	{
		if (strcmp( buf, s.buf ) < 0)
		{
			return true;
		}
		return false;
	}

    bool operator <= ( const String s )
	{
		int cmp_value = strcmp(buf, s.buf);
		if (cmp_value <= 0)
		{
			return true;
		}
		return false;
	}
	
    bool operator >= ( const String s )
	{
		int cmp_value = strcmp(buf, s.buf);
		if (cmp_value >= 0)
		{
			return true;
		}
		return false;
	}

    	   /// concatenates this and s to return result
   	String operator + ( const String s )
	{
		char * result = new char[MAXLEN];
		strcpy(result, buf);
		if (inBounds(strlen(result) + strlen(s.buf)))
		{
			cout << "String concatenation too long. Exceed 127 char limit" << endl;
			cout << "Strings being concatenated and their lengths: " << result << strlen(result) << s.buf << strlen(s.buf) << endl;
			return String(buf);
		}
		
		return String(strcat(result, s.buf));
	}
    	   /// concatenates s onto end of this string
    String operator += ( const String s )
	{
		if (inBounds(strlen(buf) + strlen(s.buf)))
		{
			cout << "String concatenation too long. Exceed 127 char limit" << endl;
			return s;
		}
		return String(strcat(buf, s.buf));
	}

    void print( ostream & out )
	{
		cout << buf;
	}

    void read( istream & in )
	{
		in.getline(buf, MAXLEN);
		in.ignore();
	}

	~String()
	{

	}
private:
	bool inBounds( int i )
	{
		return i >= 0 && i < strlen(buf);
	} // Hint: some C string primitives you should define and use

	static int strlen( const char *s )
	{
		int i;
		for (i = 0; s[i] != '\0'; ++i)
		{
			;
		}
		return (i);
	}

	static char * strcpy( char * dest, const char * src )
	{
		int i;
		for (i = 0; src[i] != '\0'; ++i)
		{
			dest[i] = src[i];
		}
		dest[i] = '\0';
		return dest;
	}

	static char * strcat( char *dest, const char *src )
	{
		int i;	
		int dest_size = strlen(dest);
		for (i = 0; src[i] != '\0'; i++)
		{
			dest[dest_size++] = src[i];
		}
		dest[dest_size] = '\0';
		return dest;
	}

	static int strcmp( const char *left, const char *right )
	{
		int i;
		for (i = 0; left[i] == right[i]; ++i)
		{
			if (left[i] == '\0')
			{
				return 0;
			}
		}
		return left[i] - right[i];
	}

	static int strncmp (const char *left, const char *right, int n )
	{
		int i;
		for (i = 0; left[i] == right[i]; ++i)
		{
			if (i + 1 == n)
			{
				return 0;
			}
			if (left [i] == '\0')
			{
				return 0;
			}
		}
		return left[i] - right[i];
	}

	static char * strchr( char *str, int c )
	{
		while (*str)
		{
			if (*str == c)
			{
				break;
			}
		str++;
		}
		return str;
	}


	/* haystack "The quick brown fox ran up the lazy log"
 * needle "ran" */
	static const char * strstr( const char *haystack, const char *needle )
	{
		int nlen = strlen(needle);	
		char c = needle[0];
		const char * p = haystack;
		while (p = strchr(const_cast<char*>(p), c))
		{
			if (strncmp(needle, p, nlen) == 0)
			{
				return p;
			}
			else
			{
				++p;
			}
		}
		return NULL;
	}

	static char * strstr( char *haystack, const char *needle )
	{
		int nlen = strlen(needle);
		char c = needle[0];
		char * p = haystack;
		while (p = strchr(p, c))
		{
			p = strchr(p, c);
			if (strncmp(needle, p, nlen) == 0)
			{
				return p;	
			}
			else
			{
				++p;
			}
		}
		return NULL;
	}

	static void reverse_cpy ( char *dest, const char *src )
	{
		int len = strlen(dest);
		int i;
		for (i = 0; i < len; ++i)
		{
			dest[i] = src[len-i-1];
		}
		dest[len] = '\0';
	}

	char buf[MAXLEN];
	// DO NOT store the 'logical' length of this string
	// use the null '\0' terminator to mark the end
};
ostream & operator << ( ostream & out, String str )
{
	str.print(cout);
}
istream & operator >> ( istream & in, String & str )
{
	str.read(cin);
}
