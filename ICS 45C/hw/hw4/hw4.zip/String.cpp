#include "String.h"

String::String(const char * s) {
	buf = strdup(s);	
}
String::String(const String & s) {
	buf = strdup(s.buf);
}
String String::operator = (const String & s) {
	delete_char_array(buf);
	buf = strdup(s.buf);
	return *this;
}
char & String::operator [] (int index) {
	if(!inBounds(index)) {
		cout << "String index out of bounds" << endl;
		index = 0;
	}
	return buf[index];
}
int String::size() {
	return strlen(buf);
}
String String::reverse() {
	char *temp = new_char_array(strlen(buf) + 1);
	reverse_cpy(temp, buf);
	String result(temp);
	delete_char_array(temp);
	return result;
}
int String::indexOf(const char c) {
	char *p = strchr(buf, c);
	if (p == NULL) {
		return -1;
	}
	else {
		return p - buf;
	}
}
int String::indexOf(const String pattern) {
	char *p = strstr(buf, pattern.buf);
	if (p == NULL) {
		return -1;
	}
	else {
		return p - buf;
	}
}
bool String::operator == (const String s) {
	if (strcmp(buf, s.buf) == 0) {
		return true;
	}
	return false;
}
bool String::operator != (const String s) {
	if (strcmp(buf, s.buf) != 0) {
		return true;
	}
	return false;
}
bool String::operator > (const String s) {
	if (strcmp(buf, s.buf) > 0) {
		return true;
	}
	return false;
}
bool String::operator < (const String s) {
	if (strcmp(buf, s.buf) < 0) {
		return true;
	}
	return false;
}
bool String::operator <= (const String s) {
	if (strcmp(buf, s.buf) <= 0) {
		return true;
	}
	return false;
}
bool String::operator >= (const String s) {
	if (strcmp(buf, s.buf) >= 0) {
		return true;
	}
	return false;
}
String String::operator + (const String s) {
	char * vessel = new_char_array(strlen(buf) + strlen(s.buf) + 1);
	strcpy(vessel, buf);
	strcat(vessel, s.buf);
	String result(vessel);
	delete_char_array(vessel);
	return result;
}
String String::operator += (const String s) {
	char * holder = new_char_array(strlen(buf) + strlen(s.buf) + 1);
	strcpy(holder, buf);
	strcat(holder, s.buf);
	delete_char_array(buf);
	buf = holder;
	return *this;
}
void String::print(ostream & out) {
	cout << buf;
}
void String::read(istream & out) {
	char * chr = new_char_array(256);
	cin.getline(chr, 256);
	delete_char_array(buf);
	buf = strdup(chr);
	delete_char_array(chr);
}
String::~String() {
	delete_char_array(buf);
}
bool String::inBounds(int i) {
	return i >= 0 && i < strlen(buf);
}
int String::strlen(const char *s) {
	int i;
	for (i = 0; s[i] != '\0'; ++i) {
		;
	}
	return i;
}
char *String::strcpy(char *dest, const char *src) {
	int i;
	for (i = 0; src[i] != '\0'; ++i) {
		dest[i] = src[i];
	}
	dest[i] = '\0';
	return dest;
}
char *String::strdup(const char *src) {
	return strcpy(new_char_array(strlen(src) + 1), src);
}
int String::strcmp(const char *left, const char *right) {
	int i;
	for (i = 0; left[i] == right[i]; ++i) {
		if (left[i] == '\0') {
			return 0;
		}
	}
	return left[i] - right[i];
}
int String::strncmp(const char* left, const char* right, int n) {
	int i;
	for (i = 0; left[i] == right[i]; ++i) {
		if (i + 1 == n) {
			return 0;
		}
		if (left[i] == '\0') {
			return 0;
		}
	}
	return left[i] - right[i];
}
char *String::strcat(char *dest, const char *src) {
	int i;
	int j;
	for (i = 0; dest[i] != '\0'; ++i);
	for (j = 0; src[j] != '\0'; ++j) {
		dest[i+j] = src[j];
	}
	dest[i+j] = '\0';
	return dest;
}
void String::reverse_cpy(char *dest, const char *src) {
	int i;
	int j;
	for (i = 0; src[i] != '\0'; ++i);
	--i;
	for (j = 0; src[j] != '\0'; j++) {
		dest[j] = src[i-j];
	}
	dest[j] = '\0';
}
char *String::strchr(char *str, int c) {
	int i;
	for (i = 0; str[i] != c; ++i) {
		if(str[i] == 0) {
			return 0;
		}
	}
	return & str[i];
}
const char *String::strstr(const char *haystack, const char *needle) {
	int nlen;
	for (nlen = 0; needle[nlen] != '\0'; ++nlen) {
		;
	}
	char c = needle[0];
	const char *p = haystack;
	while (p = strchr(const_cast<char*>(p), c)) {
		if (strncmp(needle, p, nlen) == 0) {
			return p;
		}
		else {
			++p;
		}
	}
	return NULL;
}
char *String::strstr(char *haystack, const char *needle) {
	int nlen;
	for (nlen = 0; needle[nlen] != '\0'; ++nlen) {
		;
	}
	char c = needle[0];
	char * p = haystack;
	while (p = strchr(p, c)) {
		p = strchr(p, c);
		if (strncmp(needle, p, nlen) == 0) {
			return p;	
		}
		else {
			++p;
		}
	}
	return NULL;
}
int String::allocations = 0;
char *String::new_char_array(int n_bytes) {
	allocations++;
	return new char[n_bytes];
}

void String::delete_char_array(char *p) {
	allocations--;
	delete[] p;
}
void String::final_report_on_allocations() {
	cout << "Number of new allocations minus number of delete deallocations is " << allocations << endl;
}
ostream & operator << (ostream & out, String str) {
	str.print(cout);
}
istream & operator >> (istream & in, String & str) {
	str.read(cin);
}
