#include <iostream>
using namespace std;
#include "String.cpp"

void test_constructors_and_print()
{
	String s("Hello World");
	cout << s << endl;
}

void test_size()
{
	String s("Test");
	cout << s << " has a length of " << s.size() << endl;
}

void test_index()
{
	String s("Index");
	cout << "The character at index 3 of " << s << " is " << s[3] << endl;
}

void test_assignment()
{
	String s = String("Assignment Test");
	cout << s << endl;
}

void test_relations()
{
	cout << "Relations Tests" << endl;
	String s("relations");
	String s2("test");
	String s3("abra");
	String s4("kadabra");
	cout << "relations > test:  " << std::boolalpha << (s > s2) << endl;
	cout << "abra < kadabra: " << (s3 < s4) << endl;
	cout << "abra == abra: " << (s3 == s3) << endl;
	cout << "abra != kadabra: " << (s3 != s4) << endl;
	cout << "relations >= kadabra: " << (s >= s4) << endl;
	cout << "test <= test: " << (s2 <= s2) << endl;
}

void test_concatenate()
{
	String q("This is string 1.");
	String q2("This is string 2.");
	cout << "First String: " << q << endl;
	cout << "concatenation: " << (q + q2) << endl;
	cout << "First String: " << q << endl;
	cout << "concatenation (+=): " << (q += q2) << endl;
	cout << "First String: " << q << endl;
}

void test_reverse()
{
	String l("Four");
	cout << "Reverse \"Four\": " << l.reverse() << endl;
}

void test_indexOf()
{
	String l("Lorum");
	String um("um");
	cout << "The index of 'o' in the string \"Lorun\" is: " << l.indexOf('o') << endl;
	cout << "The index of \"um\" in the string \"Lorum\" is: " << l.indexOf(um) << endl;
}

void test_read()
{
	cout << "Enter a test string: ";
	String test = String();
	cin >> test;;
	cout << "Your string: " << test << endl;
}

int main()
{
	test_constructors_and_print();
	test_size();
	test_index();
	test_assignment();
	test_relations();
	test_concatenate();
	test_reverse();
	test_indexOf();
	test_read();
	return 0;
}


