#include <iostream>
using namespace std;

double convert( int knots )
{
	int fph = knots * 6076;
	return fph / 5280.0;
}

int main ( int rgc, char *argv[] )
{
	int i;
	cin >> i;
	cout << convert( i ) << endl;
	return 0;
}
