#include <iostream>
using namespace std; 

 #define STACK_CAPACITY 1000
  class Stack
  {

int top_i;
char s[STACK_CAPACITY];

  private:

	void error (const char* msg)
	{
	cout << "Error: " << msg << endl;
	}

  public:
    Stack()
	{
	top_i = 0;
	} // constructor for a stack
    void push( char c )
	{
	if (isFull())
	{
		error("Push on a full stack");
		return;
	}
	s[top_i] = c;
	top_i = top_i + 1;
	} // adds c to the top of the stack
    char pop()
	{
	if (isEmpty())
	{
		error("Pop on an empty stack");
		return ' ';
	}
	top_i = top_i - 1;
	return s[top_i];	
	} // removes top element, returns it
    char top()
	{
	return s[top_i];
	} // returns the top element, w/o removing
    bool isEmpty()
	{
	if (top_i == 0)
		{
		return true;
		}
	return false;
	} // returns true iff the stack is empty
    bool isFull()
	{
	if (top_i == 999)
		{
		return true;
		}
	return false;
	} // returns true iff the stack is full
    ~Stack()
	{
	} // destructor for a stack
  };

