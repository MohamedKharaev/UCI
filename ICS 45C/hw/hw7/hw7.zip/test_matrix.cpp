#include <iostream>
using namespace std;

#include <iomanip>
using namespace std;

#include "Array.h"
using namespace std;

#include "Matrix.h"
using namespace std;

template< typename T >
void fillMatrix( Matrix <T> & m )
{
  int i, j;
  for ( i = 0; i < m.numRows(); i++ )
    m[i][0] = T();
  for ( j = 0; j < m.numCols(); j++ )
    m[0][j] = T();
  for ( i = 1; i < m.numRows(); i++ )
    for ( j = 1; j < m.numCols(); j++ )
    {
      m[i][j] = T(i * j);
    }
}
void test_int_matrix()
{ // here is a start, but make it better
    Matrix<int> m(4,5);
    fillMatrix( m );
	cout << "Current Matrix: Rows (" << m.numRows() <<  ") / Cols (" << m.numCols() << ")" << endl;
    cout << m << endl;
	Matrix <int> mCopy = m;
	cout << "Copied matrix using '=' operator\n" << mCopy << endl;
}
void test_double_matrix()
{ // here is a start, but make it better
	Matrix < double > M(7,3);
    fillMatrix( M );
    cout << "Current Matrix: Rows (" << M.numRows() <<  ") / Cols (" << M.numCols() << ")" << endl;
    cout << M <<endl;
	Matrix <double> MCopy = M;
	cout << "Copied matrix using '=' operator\n" << MCopy << endl;
}
void generate_exception(Matrix<double> & m) {
	for (int i = 0; i < m.numRows() + 2; ++i) {
		try {
			cout << m[i] << endl;
		}
		catch (const IndexOutOfBoundsException & e) {
			cout << "Index out of bounds\n";
		}
	}	
}
void test_double_matrix_exceptions() {
	cout << "Starting...\n";
	Matrix < double > M(8, 10);
	fillMatrix(M);
	cout << M;
	generate_exception(M);
	cout << "Done\n";
}
int main()
{
	for (int i = 0; i < 3; ++i) {
		test_int_matrix();
		test_double_matrix();
		test_double_matrix_exceptions();
	}
	return 0;
}
