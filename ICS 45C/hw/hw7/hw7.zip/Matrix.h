template <typename Element>

class Matrix {
private:
	int rows, cols;
	Array<Array<Element>*> m;
public:
	Matrix(int newRows, int newCols) : rows(newRows), cols(newCols), m(rows) {
		for (int i = 0; i < rows; i++)
			m[i] = new Array<Element>(cols);
	}
	Matrix(Matrix & x) : rows(x.rows), cols(x.cols), m(rows) {
		for (int i = 0; i < x.rows; ++i) {
			m[i] = new Array<Element>(x[i]);
		}
	}
	int numRows() {
		return rows;
	}
	int numCols() {
		return cols;
	}
	Array<Element> & operator [] (int row) {
		if (row < 0 || row >= rows) {
			throw IndexOutOfBoundsException();
		}
		return *m[row];
	}
	Matrix<Element> & operator = (Matrix<Element> & l) {
		for (int i = 0; i < rows; ++i) {
			delete m[i];
			m[i] = new Array<Element>(l[i]);
		}
		return *this;	
	}
	void print(std::ostream & out) {
		for (int i = 0; i < rows; i++) {
			out << m[i] << endl;
		}
	}
	friend std::ostream & operator << (std::ostream & out, Matrix & m) {
		m.print(out);
		return out;
	}
	~Matrix() {
		for (int i = 0; i < rows; ++i)
			delete m[i]; 
	}
};
