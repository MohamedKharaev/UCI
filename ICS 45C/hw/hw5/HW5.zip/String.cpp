#include "String.h"

struct String::ListNode {
	char info;
	ListNode * next;
	ListNode(char newInfo, ListNode * newNext)
        : info( newInfo ), next( newNext ) {
	}
	static ListNode * stringToList(const char *s) {
		return s[0] == '\0' ? nullptr : new ListNode(s[0], stringToList(s+1));
	}
	static ListNode * copy(ListNode * L) {
		return L == nullptr ? nullptr : new ListNode(L->info, copy(L->next));
	}
	static ListNode * reverse(ListNode * L) {
		ListNode * result = nullptr;
		for (ListNode * p = L; p != nullptr; p = p->next) {
			result = new ListNode(p->info, result);
		}
		return result;
	}
	static ListNode * append(ListNode * L1, ListNode * L2) {
		return L1 == nullptr ? copy(L2) : new ListNode(L1->info, append(L1->next, L2));
	}
	static int compare(ListNode * L1, ListNode * L2) {
		if (!L1 && !L2) {return 0;}
		if (!L1 && L2) {return -1;}
		if (L1 && !L2) {return 1;}

		if (L1->info == L2->info) {
			return compare(L1->next, L2->next);
		}
		return L1->info - L2->info;
	}
	static void deleteList(ListNode * L) {
		if (L != nullptr) {
			deleteList(L->next);
			delete L;
		}
	}
	static int length(ListNode * L) {
		return L == 0 ? 0 : 1 + length(L->next);
	}
};

String::String(const char * s) {
	head = ListNode::stringToList(s);
}

String::String(const String & s) {
	head = ListNode::copy(s.head);
}

String String::operator = (const String & s) {
	ListNode::deleteList(head);
	head = ListNode::copy(s.head);
	return *this;
}

bool String::inBounds(int i) {
	return i >= 0 && i < size();
}

void String::print(ostream & out) const {
	for (ListNode * p = head; p != nullptr; p = p->next) {
		out << p->info;
	}
}

void String::read(istream & in) {
	char holder[256];
	in.getline(holder, 256);
	if (head != nullptr) {
		ListNode::deleteList(head);
	}
	head = ListNode::stringToList(holder);
}

String String::operator + (const String & s) const {
	ListNode * temp = ListNode::append(head, s.head);
	String result;
	result.head = ListNode::copy(temp);
	ListNode::deleteList(temp);
	return result;
}

String String::operator += (const String & s) {
	ListNode * temp = ListNode::append(head, s.head);
	ListNode::deleteList(head);
	head = temp;
	return *this;
}

char & String::operator [] (const int index) {
	if (head == nullptr) {
		cout << "Error: String is empty" << endl;
		head = new ListNode('a', nullptr);
	}
	ListNode * temp = head;
	if (inBounds(index)) {
		for (int i = 0; i != index; ++i) {
		temp = temp->next;
		}
	}
	return temp->info;
}

bool String::operator == (const String & s) const {
	return (ListNode::compare(head, s.head) == 0);
}

bool String::operator < (const String & s) const {
	return (ListNode::compare(head, s.head) < 0);
}

int String::size() const {
	return ListNode::length(head);
}

int String::indexOf(char c) const {
	int count = 0;
	for (ListNode * p = head; p != nullptr; p = p->next) {
		if (p->info == c) {
			return count;
		}
		count++;
	}
	return -1;
}
String String::reverse() const {
	ListNode * temp = ListNode::reverse(head);
	String result;
	result.head = ListNode::copy(temp);
	ListNode::deleteList(temp);
	return result;
}

String::~String() {
	ListNode::deleteList(head);
}

ostream & operator << (ostream & out, String str) {
	str.print(out);
	return out;
}

istream & operator >> ( istream & in, String & str ) {
	str.read(in);
	return in;
}
