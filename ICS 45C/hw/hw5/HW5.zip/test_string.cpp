#include <iostream>
using namespace std;

#include "String.cpp"

int main() {
	String test1("This is the first string");
	String test2("This is the second string");
	String test3 = String();

	cout << "test1: " << test1 << endl;
	cout << "test2: " << test2 << endl;
	cout << "test3: " << test3 << endl;

	cout << "test1[5]: " << test1[5] << endl;
	cout << "test3[1]: " << test3[1] << endl;
	cout << "test2[500]: " << test2[500] << endl;

	cout << "test1.size(): " << test1.size() << endl;
	cout << "test3.size(): " << test3.size() << endl;	

	cout << "test1.indexOf('r'): " << test1.indexOf('r') << endl;
	cout << "test3.indexOf('a'): " << test3.indexOf('a') << endl;

	cout << "test1 == test2: " << (test1==test2) << endl;
	cout << "test3 == test3: " << (test3==test3) << endl;

	cout << "test2 < test2: " << (test2<test2) << endl;
	cout << "test1 < test3: " << (test1<test3) << endl;

	cout << "test1 + test2: " << (test1+test2) << endl;
	
	cout << "test1: " << test1 << endl;
	cout << "test1 += test2: " << (test1+=test2) << endl;
	cout << "test1: " << test1 << endl;

	cout << "test2.reverse(): " << test2.reverse() << endl;
	
	cout << "cin >> test1: ";
	cin >> test1;
	cout << "test1: " << test1 << endl;

	return 0;
}
