class String {
public:
	explicit String(const char * s = "");
	String(const String & s);
	String operator = (const String & s);
	char & operator [] (const int index);
	int size() const;
	int indexOf(char c) const;
	bool operator == (const String & s) const;
	bool operator < (const String & s) const;
	String operator + (const String & s) const;
	String operator += (const String & s);
	String reverse() const;
	void print(ostream & out) const;
	void read(istream & in);
	~String();
private:
	bool inBounds(int i);
	struct ListNode;
	ListNode * head;
};
ostream & operator << (ostream & out, String str);
istream & operator << (istream & in, String & str);
