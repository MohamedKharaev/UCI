#include <iterator>

template <typename Type> struct ListNode {
	ListNode<Type> * next;
	Type info;

	ListNode<Type>(Type newInfo, ListNode<Type> * newNext) : info(newInfo), next(newNext) {
	}

	ListNode<Type>(const ListNode<Type> & L) : info(L->info), next(copy(L->next)) {
	}

	ListNode<Type> operator = (const ListNode<Type> & L) {
		deleteList(next);
		next = copy(L.next);
		return *this;
	}
	
	static ListNode<Type> * copy(ListNode<Type> * L) {
		return L == nullptr ? nullptr : new ListNode(L->info, copy(L->next));
	}

	static void deleteList(ListNode<Type> * L) {
		if (L != nullptr) {
			deleteList(L -> next);
		}
		delete L;
	}
	
	static bool findValue(ListNode<Type> * L, Type value) {
		while (L != nullptr) {
			if (L -> info == value) {
				return true;
			}
			L = L -> next;
		}
		return false;
	}

	static int compare(ListNode<Type> * L1, ListNode<Type> * L2) {
		if (!L1 && !L2) {return 0;}
		if (!L1 && L2) {return -1;}
		if (L1 && !L2) {return 1;}

		if (L1 -> info == L2 -> info) {
			return compare(L1 -> next, L2 -> next);
		}
		return (L1 -> info) - (L2 -> info);
	}
};

template <typename Type> class SetList {
	ListNode<Type> * head;

public:
    SetList<Type>(ListNode<Type> * newHead = nullptr) : head(newHead) {
    }

	struct iterator {
		typedef std::forward_iterator_tag iterator_category;
		typedef iterator self_type;
		typedef Type value_type;
		typedef Type & reference;
		typedef ListNode<Type> * pointer;
		typedef ptrdiff_t difference_type;

	private:
		pointer ihead;
	public:
		iterator(pointer ptr) : ihead(ptr) {
		}
		self_type operator++() {
			ihead = ihead -> next;
			return *this;
		}
		self_type operator++(int postfix) {
			self_type cpy = *this;
			ihead = ihead -> next;
			return cpy;
		}
		reference operator *() {
			return ihead -> info;
		}
		pointer operator -> () {
			return ihead;
		}
		bool operator == (const self_type & rhs) const {
			return ihead == rhs.ihead;
		}
		bool operator != (const self_type & rhs) const {
			return ihead != rhs.ihead;
		}
	};

	struct const_iterator {
		typedef forward_iterator_tag iterator_category;
		typedef const_iterator self_type;
		typedef Type value_type;
		typedef Type & reference;
		typedef ListNode<Type> * pointer;
		typedef ptrdiff_t difference_type;

	private:
		pointer ihead;
	public:
		const_iterator(pointer ptr) : ihead(ptr) {
		}
		self_type operator++() {
			ihead = ihead -> next;
			return *this;
		}
		self_type operator++(int postfix) {
			self_type cpy = *this;
			ihead = ihead -> next;
			return cpy;
		}
		const reference operator * () {
			return ihead -> info;
		}
		const reference operator -> () {
			return ihead;
		}
		bool operator == (const self_type & rhs) const {
			return ihead == rhs.ihead;
		}
		bool operator != (const self_type & rhs) const {
			return ihead != rhs.ihead;
		}
	};

	SetList<Type> operator = (const SetList<Type> & S) {
		ListNode<Type>::deleteList(head);
		head = ListNode<Type>::copy(S.head);
		return *this;
	}
	
	iterator begin() {
		return iterator(head);
	}
	iterator end() {
		return iterator(nullptr);
	}

	const_iterator begin() const {
		return iterator(head);
	}
	const_iterator end() const {
		return iterator(nullptr);
	}

	iterator find (Type data) {
		ListNode<Type> * temp = head;
		if (temp) {
			int i = 0;
			for (i; temp -> next != nullptr && temp-> info != data; i++) {
				temp = temp -> next;
			}
			if (temp -> info == data) {
				return iterator(temp);
			}
		}
		return iterator(nullptr);
	}
	
	void insert(Type data) {
		if (not ListNode<Type>::findValue(head, data)) {
			head = new ListNode<Type>(data, head);
		}
	}	

	~SetList<Type>() {
		ListNode<Type>::deleteList(head);
	}
};

