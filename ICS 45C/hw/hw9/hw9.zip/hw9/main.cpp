#include <iostream>
using namespace std;

#include "SetList.h"
#include "MapArray.h"
#include <fstream>
#include <vector>
#include <map>
#include <iterator>
#include <string>
#include <algorithm>

void print(pair<string, int> s) {
	cout << s.first << endl;
}

int main() {
	ifstream stopwordsin("stopwords.txt");
	ifstream wordsin("sample_doc.txt");
	ofstream frequency("frequency.txt");

	SetList<string> stopwords;
	MapArray<string, int> words_m;

	for_each(istream_iterator<string>(stopwordsin), istream_iterator<string>(), [&](const string & s) {stopwords.insert(s);});

	for_each(istream_iterator<string>(wordsin), istream_iterator<string>(), [&](const string & s) {if (stopwords.find(s) == stopwords.end()) words_m[s]++;} );

	for_each(words_m.begin(), words_m.end(), [&](const pair<string, int> & m) {frequency << m.first << ": " << m.second << endl;});	

	return 0;
}
