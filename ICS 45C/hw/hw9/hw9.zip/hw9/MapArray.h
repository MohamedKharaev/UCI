template <typename T1, typename T2> class MapArray {
	typedef pair<T1, T2> P;
	P * buf[10000];
	int top;
public:
	struct iterator {
		typedef std::random_access_iterator_tag iterator_category;
		typedef iterator self_type;
		typedef P value_type;
		typedef P & reference;
		typedef P * pointer;
		typedef ptrdiff_t difference_type;
	
	private:
		pointer ibuf;
	
	public:
		iterator(pointer ptr) : ibuf(ptr) {
		}
		self_type operator ++ () {
			++ibuf;
			return *this;
		}
		self_type operator ++ (int postfix) {
			self_type cpy = *this;
			ibuf++;
			return cpy;
		}
		reference operator * () {
			return *ibuf;
		}
		pointer operator -> () {
			return ibuf;
		}
		bool operator == (const self_type & rhs) const {
			return ibuf == rhs.ibuf;
		}
		bool operator != (const self_type & rhs) const {
			return ibuf != rhs.ibuf;
		}
	};
	
	struct const_iterator {
		typedef std::random_access_iterator_tag iterator_category;
		typedef const_iterator self_type;
		typedef P value_type;
		typedef P & reference;
		typedef P * pointer;
		typedef ptrdiff_t difference_type;

	private:
		pointer ibuf;

	public:
		const_iterator(pointer ptr) : ibuf(ptr) {
		}
		self_type operator ++ () {
			++ibuf;
			return *this;
		}
		self_type operator ++ (int postfix) {
			self_type cpy = *this;
			ibuf++;
			return cpy;
		}
		const reference operator * () {
			return *ibuf;
		}
		const pointer operator -> () {
			return ibuf;
		}
		bool operator == (const self_type & rhs) const {
			return ibuf == rhs.ibuf;
		}
		bool operator != (const self_type & rhs) const {
			return ibuf != rhs.ibuf;
		}
	};

	MapArray<T1, T2>() : top(-1) {}

	iterator begin() {
		return iterator(*buf);
	}
	iterator end() {
		return iterator(*buf + top);
	}

	const_iterator begin() const {
		return const_iterator(*buf);
	}
	const_iterator end() const {
		return const_iterator(*buf + top);
	}

	T2 & operator [] (const T1 & index) {
		int item_index = find(index);
		if (item_index == -1) {
			buf[++top] = new pair<T1, T2>(index, T2());
			return buf[top] -> second;
		}
		else {
			return buf[item_index] -> second;
		}
	}

	int find(const T1 & index) {
		if (top == 0) {
			return -1;
		}
		for (int i = 0; i < top; ++i) {
			if (buf[i] -> first == index) {
				return i;
			}
		}
		return -1;
	}

	~MapArray() {
		for (top; top > 0; top--) {
			delete buf[top];
		}
	}
};
