#include <iostream>
using namespace std;

#include <fstream>
#include <set>
#include <vector>
#include <map>
#include <iterator>
#include <string>
#include <algorithm>

int main() {
	ifstream stopwordsin("stopwords.txt");
	ifstream wordsin("sample_doc.txt");
	ofstream frequency("frequency.txt");

	set<string> stopwords;
	vector<string> words_v;
	map<string, int> words_m;

	copy(istream_iterator<string>(stopwordsin), istream_iterator<string>(), inserter(stopwords, stopwords.end()));

	copy(istream_iterator<string>(wordsin), istream_iterator<string>(), inserter(words_v, words_v.end())); 

	for_each(words_v.begin(), words_v.end(), [&](string & s) {transform(s.begin(), s.end(), s.begin(), ::tolower);});

	for_each(words_v.begin(), words_v.end(), [&](const string & s) {if (stopwords.find(s) == stopwords.end()) words_m[s]++;} );	

	for_each(words_m.begin(), words_m.end(), [&](pair <string, int> m) {frequency << m.first << ": " << m.second << endl;});	

	return 0;
}
