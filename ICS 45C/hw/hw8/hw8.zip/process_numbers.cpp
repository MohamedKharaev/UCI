#include <iostream>
using namespace std;

#include <fstream>
#include <set>
#include <vector>
#include <map>
#include <iterator>
#include <string>
#include <algorithm>

int main() {
	ifstream numbersin("rand_numbers.txt");
	ofstream odd("odd.txt");
	ofstream even("even.txt");

	vector<int> numbers;
	
	copy(istream_iterator<int>(numbersin), istream_iterator<int>(), inserter(numbers, numbers.end()));	

	sort(numbers.begin(), numbers.end());

	for_each(numbers.begin(), numbers.end(), [&](int i) {(i % 2 == 0) ? even << i << "\n" : odd << i << " ";});

	return 0;
}
