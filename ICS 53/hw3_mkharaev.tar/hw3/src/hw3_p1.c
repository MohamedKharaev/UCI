#include "hw3_p1.h"

int intComparator(void* p, void* q) {
    return ((int)p - (int)q);
}

int strComparator(void* str1, void* str2) {
    char* s1 = (char*)str1, *s2 = (char*)str2;
    for (; *s1 && *s2 && *s1 == *s2; ++s1, ++s2){}
    if (*s1 < *s2){
        return -1;
    }
    else if (*s1 > *s2){
        return 1;
    }
    return 0;
}

int idComparator(void *student1, void *student2){
	//Insert Code here
	Student *s1 = (Student*)student1, *s2 = (Student*)student2;
	if (s1->id < s2->id) {
		return -1;
	} else if (s1->id > s2->id) {
		return 1;
	} else {
    	return 0;
	}
}	

int nameComparator(void *student1, void *student2){
	//Insert Code here
	Student *s1 = (Student*)student1, *s2 = (Student*)student2;
	int result = strcmp(s1->name.lastName, s2->name.lastName);
	if (result == 0) {
		result = strcmp(s1->name.firstName, s2->name.firstName);
	}
	if (result == 0) {
		result = strcmp(s1->name.middleName, s2->name.middleName);
	}
	if (result == 0) {
		result = idComparator(student1, student2);
	}
	return (result < 0) ? -1 : (result > 0) ? 1 : 0;
}

int totalHWComparator(void *student1, void *student2){
	//Insert Code here
	Student *s1 = (Student*)student1, *s2 = (Student*)student2;
	int s1scores = 0;
	int s2scores = 0;
	int i;
	for (i = 0; i < 3; i++) {
		s1scores += s1->hw_score[i];
		s2scores += s2->hw_score[i];
	}
	return (s1scores < s2scores) ? -1 : (s1scores > s2scores) ? 1 : idComparator(student1, student2);
}

int totalMidtermComparator(void *student1, void *student2){
	//Insert Code Here
    Student *s1 = (Student*)student1, *s2 = (Student*)student2;
	int s1scores = s1->m_scores->m1_score + s1->m_scores->m2_score;
	int s2scores = s2->m_scores->m1_score + s2->m_scores->m2_score;
	return (s1scores < s2scores) ? -1 : (s1scores > s2scores) ? 1 : idComparator(student1, student2);
}

int totalPtsComparator(void *student1, void *student2){
	//Insert Code Here
    Student *s1 = (Student*)student1, *s2 = (Student*)student2;
	int s1scores = 0;
	int s2scores = 0;
	int i;
    for (i = 0; i < 3; i++) {
        s1scores += s1->hw_score[i];
        s2scores += s2->hw_score[i];
    }
	s1scores += (s1->m_scores->m1_score + s1->m_scores->m2_score);
	s2scores += (s2->m_scores->m1_score + s2->m_scores->m2_score);
	return (s1scores < s2scores) ? -1 : (s1scores > s2scores) ? 1 : idComparator(student1, student2);
}

void printCSVStudentList(List_t *list){
    //Insert Code Here
    Student * student;
	node_t * studentnode = list->head;
	int i;
	for (i = 0; i < list->length; i++) {
		student = (Student*)studentnode->value;
	    printf("%d,%s,%s,%s,%d,%d,%d,%d,%d,%d\n",
            student->id,
            student->name.firstName,
            student->name.lastName,
            student->name.middleName,
            student->hw_score[0],
            student->hw_score[1],
            student->hw_score[2],
            student->m_scores->m1_score,
            student->m_scores->m2_score,
            student->final);
		studentnode = studentnode->next;
	}	
}

