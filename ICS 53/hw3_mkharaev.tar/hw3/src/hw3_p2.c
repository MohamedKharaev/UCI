#include "hw3_p2.h"

uint16_t verifyIPV4Checksum(IPV4_header* header) {
    //Insert Code Here
    int hexlength = header->header_length;
	uint16_t *IPV4 = (uint16_t*)header;
	int i;
	long checksum = 0x00;
	for (i = 0x00; i < hexlength * 2; i++) {
		checksum += IPV4[i];
	}
	if (checksum >= 0xffff) {
		checksum = checksum + (checksum / 0x10000);
	}
	return ~checksum;
}
