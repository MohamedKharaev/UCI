#include "hw3_p3.h"

IPV4_validation validateIPV4List(List_t* packets) {
    IPV4_validation valid;
    //Insert Code Here
	valid.packet = NULL;
	valid.errcode = 0;
	node_t *packets_p = packets->head;
	while (packets_p != NULL) {
		IPV4_node *packet_node = malloc(sizeof(IPV4_node) + sizeof(IPV4_header));
		packet_node = (IPV4_node *)packets_p->value;
		IPV4_header *packet_header = (IPV4_header *)packet_node->sop;

		uint16_t checksumverify = verifyIPV4Checksum(packet_header);
		if (checksumverify != 0x0000) {
			IPV4_validation invalid_checksum;
			invalid_checksum.packet = packet_node;
			invalid_checksum.errcode = 1;
			return invalid_checksum;
		}
		
        int payload_l = packet_header->total_length - (packet_header->header_length * 4);
		packet_node->payload_len = payload_l;
		packet_node->payload = (char*)packet_node->sop + payload_l;
		packet_node->fragment_offset = packet_header->fragment_offset;

		if (packets_p->next != NULL) {
			uint16_t offset_plus_payload_length = packet_node->fragment_offset + (uint16_t)payload_l;
			IPV4_node *next_packet = (IPV4_node *)packets_p->next->value;
			IPV4_header *next_packet_header = (IPV4_header *)next_packet->sop;
			uint16_t next_offset = next_packet_header->fragment_offset;
			if (next_offset != offset_plus_payload_length) {
				IPV4_validation missing_packet;
				missing_packet.packet = packet_node;
				missing_packet.errcode = 2;
				return missing_packet;
			}
		}

		packets_p = packets_p->next;
	}
    return valid;
}
