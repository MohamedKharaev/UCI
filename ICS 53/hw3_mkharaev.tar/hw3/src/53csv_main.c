#include "hw3_p1.h"
#include "linkedList.h"

// 53csv implemenation 
int main(int argc, char* argv[]){
	//Insert Code here
	List_t *list = malloc(sizeof(List_t));
	list->length = 0;
	int (*comparator_p)(void *, void*);
	switch(atoi(argv[1])) {
		case 1:
			comparator_p = &idComparator;
			break;
		case 2:
			comparator_p = &nameComparator;
			break;
		case 3:
			comparator_p = &totalHWComparator;
			break;
		case 4:
			comparator_p = &totalMidtermComparator;
			break;
		case 5:
			comparator_p = &totalPtsComparator;
			break;
	}
	list->comparator = comparator_p;

	char *csv_line = (char *)malloc(1024);
	while (csv_line = fgets(csv_line, 1024, stdin)) {
		Student * student = (Student *)malloc(sizeof(Student*));
		student->name.firstName = (char *)malloc(50);
		student->name.middleName = (char *)malloc(50);
		student->name.lastName = (char *)malloc(50);
		student->m_scores = (Midterms *)malloc(sizeof(Midterms*));		
		int sid = atoi(strsep(&csv_line, ","));
		char *sfn = strsep(&csv_line, ",");
		char *sln = strsep(&csv_line, ",");
		char *smn = strsep(&csv_line, ",");
		int hw1 = atoi(strsep(&csv_line, ","));
		int hw2 = atoi(strsep(&csv_line, ","));
		int hw3 = atoi(strsep(&csv_line, ","));
		int ms1 = atoi(strsep(&csv_line, ","));
		int ms2 = atoi(strsep(&csv_line, ","));
		int final = atoi(csv_line);
		student->id = sid;
		student->name.firstName = sfn;
		student->name.lastName = sln;
		student->name.middleName = smn;
		student->hw_score[0] = hw1;
		student->hw_score[1] = hw2;
		student->hw_score[2] = hw3;
		student->m_scores->m1_score = ms1;
		student->m_scores->m2_score = ms2;
		student->final = final;
		insertInOrder(list, (void*)student);	
	}
	
	printCSVStudentList(list);	
	return 0;
}

