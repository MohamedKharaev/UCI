// Mohamed Kharaev
// mkharaev

#include "morsecode.h"
#include "hw2.h"
#include "helpers2.h"

char* MorseCode[] = {MorseExclamation, MorseDblQoute, MorseHashtag, Morse$, MorsePercent, MorseAmp, MorseSglQoute, MorseOParen, MorseCParen, MorseStar, MorsePlus, MorseComma, MorseDash, MorsePeriod, MorseFSlash, Morse0, Morse1, Morse2, Morse3, Morse4, Morse5, Morse6, Morse7, Morse8, Morse9, MorseColon, MorseSemiColon, MorseLT, MorseEQ, MorseGT, MorseQuestion, MorseAt, MorseA, MorseB, MorseC, MorseD, MorseE, MorseF, MorseG, MorseH, MorseI, MorseJ, MorseK, MorseL, MorseM, MorseN, MorseO, MorseP, MorseQ, MorseR, MorseS, MorseT, MorseU, MorseV, MorseW, MorseX, MorseY, MorseZ};

/* Part 1 Functions */
int toMorse(FILE *instream, char **mcmsg_ptr){
        // Insert code here
		*mcmsg_ptr = (char*)malloc(5 * sizeof(char));
		if (*mcmsg_ptr == NULL) {
			return -1;
		}
		int letter;
		char * mcode;
		int i;
		int mcmsg_ptr_count = 0;
		while ((letter = fgetc(instream)) != EOF) {
			if (letter < 0 || letter > 127) {
				return 0;
			}
			if (letter > 96 && letter < 123) {
				letter = letter - 32;
			}
			if (letter == 32) {
				if (*(*mcmsg_ptr + mcmsg_ptr_count - 2) == 'x') {
					continue;
				}
				*(*mcmsg_ptr + mcmsg_ptr_count++) = 'x';
				*mcmsg_ptr = (char*)realloc(*mcmsg_ptr, 1 + mcmsg_ptr_count);
				continue;
			}
			if (letter < 33 || letter > 90) {
				continue;
			}
			mcode = *(MorseCode + (letter - 33));
			for (i = 0; i < mystrlen(mcode); i++) {
				*(*mcmsg_ptr + mcmsg_ptr_count++) = *(mcode + i);
				*mcmsg_ptr = (char*)realloc(*mcmsg_ptr, 1 + mcmsg_ptr_count);
			}
			*(*mcmsg_ptr + mcmsg_ptr_count++) = 'x';
			*mcmsg_ptr = (char*)realloc(*mcmsg_ptr, 1 + mcmsg_ptr_count);
		}
		if (*(*mcmsg_ptr + mcmsg_ptr_count - 2) != 'x') {
			*(*mcmsg_ptr + mcmsg_ptr_count++) = 'x';
			*mcmsg_ptr = (char*)realloc(*mcmsg_ptr, 1 + mcmsg_ptr_count);
		}
		*(*mcmsg_ptr + mcmsg_ptr_count++) = '\0';
		return 1;
}

void createKey(char* keyphrase, char* key){
    // Insert code here
    const char * alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    char *kp = key;
	int keylen = 0;
	char letter;
    while (*keyphrase != '\0') {
		letter = *keyphrase;
		if (letter > 96 && letter < 123) {
			letter = letter - 32;
		}
		if (letter < 65 || letter > 90) {
			keyphrase++;
			continue;
		}
		if (ischarin(letter, key, keylen) == 1) {
			keyphrase++;
			continue;
		}
		*kp = letter;
		keylen++;
		kp++;
		keyphrase++;
	}
	int i;
	for (i = 0; i < 26; i++) {
		if (ischarin(*(alphabet + i), key, keylen) == 0) {
			*kp = *(alphabet + i);
			kp++;
		}  
	}
}

char morseToKey(char* mcmsg, char* key){
    char* FMCarray = ".....-..x.-..--.-x.x..x-.xx-..-.--.x--.-----x-x.-x--xxx..x.-x.xx-.x--x-xxx.xx-";
    // Insert code here
    char* first3char = malloc(3 * sizeof(char));
	int i;
	if (mystrlen(mcmsg) < 3) {
		return -1;
	}
	
	for (i = 0; i < 3; i++) {
		*(first3char + i) = *(mcmsg + i);
	}
	for (i = 0; i < 26; i++) {
		if (*(first3char + 0) == *(FMCarray + (i * 3) + 0)) {
			if (*(first3char + 1) == *(FMCarray + (i * 3) + 1)) {
				if (*(first3char + 2) == *(FMCarray + (i * 3) + 2)) {
					return *(key + i);
				}
			}
		}
	} 
    return -1;
}

int FMCEncrypt(FILE *instream, char* key, FILE *outstream){
        // Insert code here
        char **mcmsg = malloc(1 * sizeof(char*));
		toMorse(instream, mcmsg);
		int i;
		char **morsemcmsg = mcmsg;
		int mcmsglen = mystrlen(*mcmsg) / 3;
		for (i = 0; i < mcmsglen; i++) {
			fputc(morseToKey(*morsemcmsg, key), outstream);
			*morsemcmsg = *morsemcmsg + 3;
		}
		return 1;
}


/* Part 2 Functions */
int fromMorse(char *mcmsg, FILE* outstream){
        // Insert code here
        int i = 0;
		char *mcletter = malloc(1);
		while (*(mcmsg + 1) != '\0') {
			if (*(mcmsg + i) == 'x') {
				if (i == 0) {
					fputc(32, outstream);
					mcmsg = mcmsg + 1;
				} else {
					mcletter = NULL;
					mcletter = realloc(mcletter, (i + 1) * sizeof(char));
					int j;
					for (j = 0; j < i; j++) {
						*(mcletter + j) = *(mcmsg + j);
					}
					*(mcletter + j + 1) = '\0';
					int k ;
					for (k = 0; k < 58; k++) {
						if (mystrcmp(mcletter, *(MorseCode + k)) == 0) {
							fputc((k + 33), outstream);
							break;
						}
					}
					mcmsg = mcmsg + i + 1;

					i = 0;
				}
			} else {
				i++;
			} 
		} 
        return 1;
}

int FMCDecrypt(FILE *instream, char* key, FILE *outstream){
        // Insert code here
        char *mcmsg_ptr = (char*)malloc(5 * sizeof(char));
        if (mcmsg_ptr == NULL) {
            return -1;
        }
        int letter;
		int mcmsg_ptr_count = 0;
		while ((letter = fgetc(instream)) != EOF) {
			mcmsg_ptr = (char*)realloc(*mcmsg_ptr, 1 + mcmsg_ptr_count);
			mcmsg_ptr_count++;
		}
		fromMorse(mcmsg_ptr, outstream);
}
