// Define all helper functions for hw2 in this file
#include "helpers2.h"

int mystrlen(char * s) {
	int len = 0;
	while (*(s + len) != '\0') {
		len++;
	}
	return len;
}

int ischarin(char c, char *cs, int len_cs) {
	int i;
	for (i = 0; i < len_cs; i++) {
		if (*(cs + i) == c) {
			return 1;
		}
	}
	return 0;
}

int mystrcmp(char * s1, char * s2) {
	int i = 0;
	while ((*s1 != '\0') || (*s2 != '\0')) {
		if (*s1 > *s2)
			return 1;
		if (*s1 < *s2)
			return 1;
		s1++;
		s2++;
	}
	return 0;
}	
