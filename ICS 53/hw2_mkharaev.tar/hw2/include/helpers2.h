// Declare all helper functions for hw2 in this file

extern int mystrcmp(char * s1, char * s2);
extern int ischarin(char c, char *cs, int len_cs);
extern int mystrlen(char * s);
