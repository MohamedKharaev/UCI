#include "node.h"

// implement member functions for the Node class here
Node::Node() {

}

Node::Node(int i) {
	this->id = i;
}